import MarketForm from './components/MarketForm';
import './App.css';

function App() {
  return (
    <div className="App">
      <MarketForm />
    </div>
  );
}

export default App;
